class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/tensorboard'    # Directory for tensorboard files.
        self.pretrained_networks = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/pretrained_networks'
        self.lasot_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/lasot'
        self.got10k_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/got10k/train'
        self.got10k_val_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/got10k/val'
        self.lasot_lmdb_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/lasot_lmdb'
        self.got10k_lmdb_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/got10k_lmdb'
        self.trackingnet_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/trackingnet'
        self.trackingnet_lmdb_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/trackingnet_lmdb'
        self.coco_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/coco'
        self.coco_lmdb_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/coco_lmdb'
        self.lvis_dir = ''
        self.sbd_dir = ''
        self.imagenet_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/vid'
        self.imagenet_lmdb_dir = 'C:/Users/rizam/Desktop/CENG/Altek/ComputerVision/Tracking_Imps/AVTrack/data/vid_lmdb'
        self.imagenetdet_dir = ''
        self.ecssd_dir = ''
        self.hkuis_dir = ''
        self.msra10k_dir = ''
        self.davis_dir = ''
        self.youtubevos_dir = ''
